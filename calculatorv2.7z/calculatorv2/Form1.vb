﻿Public Class Form1
    Dim mdisplay As Display
    Dim mtuple As Tuple
    Dim order
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mdisplay = New Display(0)
        mtuple = New Tuple()
        order = New ArrayList()
        order.add(New ArrayList({radical.Text})) 'i think the rad should go first so √2(4) ^ 2 = 
        order.add(New ArrayList({Exponent.Text}))
        order.add(New ArrayList({Multiply.Text, Divide.Text, Modulus.Text}))
        order.add(New ArrayList({Plus.Text, Minus.Text}))
        'radical goes last cuz everything inside the radical needs to get done

        Log.Text = "log" & ChrW(&H2081) & ChrW(&H2080) 'subscript 10
        Log2.Text = "log" & ChrW(&H2082) 'subscript 2
        pi.Text = ChrW(&H3C0) 'pi
        mode = radian.Text
        deg.Enabled = True
        test.Run()
        Console.WriteLine(Jank.ln(Math.E))
        For i = 0 To 99
            LeftParen.PerformClick()
        Next
    End Sub

    Public Class test
        Shared pass = True
        Public Shared Sub Run()
            SubRun()
            Console.WriteLine("all test case have")
            testOut(pass)
        End Sub

        Public Shared Sub SubRun()
            Form1.Clear.PerformClick()
            Form1.Clear.PerformClick()
            Form1.Cos.PerformClick()
            Form1.radian.PerformClick()
            Form1.pi.PerformClick()
            Form1.Equal.PerformClick()
            Console.WriteLine("cos of pi in radian mode")
            testOut(Form1.mdisplay.vget() = -1)

            Form1.Clear.PerformClick()
            Form1.Clear.PerformClick()
            Form1.Cos.PerformClick()
            Form1.deg.PerformClick()
            Form1.Button1.PerformClick()
            Form1.Button8.PerformClick()
            Form1.Button0.PerformClick()
            Form1.Equal.PerformClick()
            Console.WriteLine("cos of pi in deg mode")
            testOut(Form1.mdisplay.vget() = -1)

            Form1.Clear.PerformClick()
            Form1.Clear.PerformClick()
            Form1.Sin.PerformClick()
            Form1.radian.PerformClick()
            Form1.pi.PerformClick()
            Form1.Equal.PerformClick()
            Console.WriteLine("sin of pi in radian mode")
            testOut(Form1.mdisplay.vget() = 0)

            Form1.Clear.PerformClick()
            Form1.Clear.PerformClick()
            Form1.Sin.PerformClick()
            Form1.deg.PerformClick()
            Form1.Button1.PerformClick()
            Form1.Button8.PerformClick()
            Form1.Button0.PerformClick()
            Form1.Equal.PerformClick()
            Console.WriteLine("sin of pi in deg mode")
            testOut(Form1.mdisplay.vget() = 0)
        End Sub

        Public Shared Sub testOut(bool As Boolean)
            Console.WriteLine()
            Console.WriteLine("test case " & If(bool, "pass", "fail"))
            If Not bool Then
                pass = False
            End If
        End Sub
    End Class

    Public Class Display
        Public Sub operateAssign(x As Object, y As Object, op As String)
            vset(Form1.Operander(x, y, op))
        End Sub

        Public Function vget() As Double
            Return Form1.TextBox1.Text
        End Function

        Public Sub vset(x As String)
            Dim check = x.Contains(".")
            While x.StartsWith("0") And x.Length() > 1 And Not check
                x = x.Remove(0, 1) 'asset x never equals 00.
            End While
            Form1.TextBox1.Text = x
        End Sub

        Public Function reset()
            Dim temp = Form1.TextBox1.Text
            vset(0)
            Return temp
        End Function

        Public Sub New(x As Object)
            vset(x)
        End Sub
    End Class

    Public Class Tuple
        Public ops As ArrayList
        Public numbers As ArrayList
        Public windex As Integer
        Public leftCount = 0

        Public Sub New()
            ops = New ArrayList()
            numbers = New ArrayList()
        End Sub

        Public Shared Function IsDouble(x As String)
            Select Case x
                Case Form1.Exponent.Text, Form1.Multiply.Text, Form1.Divide.Text, Form1.Plus.Text, Form1.Minus.Text, Form1.radical.Text
                    Return True
                Case Else
                    Return False
            End Select
        End Function

        Public Sub RefilWindex(end0 As Integer) 'todo get better names
            windex = 0
            Dim i = 0
            While i < end0
                If IsDouble(ops.Item(i)) Then
                    windex += 1
                End If
                i += 1
            End While
        End Sub

        Public Function Reset()
            leftCount = 0
            Dim anw = Form1.Pull(numbers, 0)
            ops.Clear()
            numbers.Clear()
            Form1.RightParen.Enabled = False
            Return anw
        End Function

    End Class

    Public Class Jank
        Public Const PI = 3.14159265358979

        Public Shared Function log(x As Double, base As Double) As Double
            Return ln(x) / ln(base)
        End Function

        Public Shared Function ln(x As Double) As Double
            Dim anw As Double
            Dim fraction = (x - 1) / (x + 1)
            Dim maffs = Function(n) (2 * n + 1)
            For i = 0 To 100
                Dim quick = maffs(i)
                anw += Exp(fraction, quick) / quick
            Next
            Return 2 * anw
        End Function

        Public Shared Function Abs(x As Object)
            Return If(x < 0, 0 - x, x)
        End Function

        Public Shared Function Exponent(x As Double, y As Double)
            'turn fraction into improper fraction
            'the find gcd of nominator and denominator
            'divide both the gcd
            'do exponent then do radidcal
            Dim neg = y < 0
            y = Abs(y) 'on line baby
            'Dim exp As Long
            'exp = (y << 1 >> 53)
            'If exp < 1023 Then

            'End If
            'End If
            'End If
            Dim counter = 0
            While y <> y \ 1 'this shiz is jank
                y *= 2
                counter += 1
            End While
            counter = Exp(2, counter)
            Console.WriteLine("radical is " & counter)
            Dim gc = gcd(y, counter)
            y /= gc
            counter /= gc
            x = Radical(x, counter)
            x = Exp(x, y)
            Return If(neg, 1 / x, x) 'todo use bit hacking to flip the expoent
        End Function

        Public Shared Function Exp(a As Double, b As ULong) As Double 'todo add caching
            If b = 0 Then
                Return 1
            ElseIf b Mod 2 = 1 Then
                Return a * Exp(a, b - 1)
            Else
                Dim p = Exp(a, b / 2)
                Return p * p
            End If
        End Function

        Public Shared Function gcd(a As Long, b As Long)
            Dim temp As Long
            While b <> 0
                temp = b
                b = a Mod b
                a = temp
            End While
            Return a
        End Function

        Public Shared Function Radical(x As Double, n As Double) 'todo finish
            If n <= 1 Then
                Return x
            End If
            x = Abs(x)
            x = newton(x, 0.5, n)
            Return x
        End Function

        'lets play a guessing game
        Const acceptable = 0.00000000000001
        Public Delegate Function f(a As Double, b As Double) As Double
        Public Shared Function newton(input As Double, x0 As Double, n As Double) As Double 'x is the guess
            'or should it be abs (x1- input)?
            While Abs(Exp(x0, n) - input) > acceptable
                x0 = x0 - ((Exp(x0, n) - input) / Exp(n * x0, n - 1))
                'x0 = x0 - (f0.Invoke(x0, n) / fPrime(x0, n))
            End While
            Return x0
        End Function

        Public Shared Function Tan(value As Double) As Double
            Return Sin(value) / Cos(value)
        End Function

        Public Shared Function Sin(value As Double) As Double
            If Form1.mode = Form1.deg.Text Then
                Return Cos(value - 90)
            Else
                Return Cos(value - PI / 2)
            End If
        End Function

        Public Shared Function Cos(value As Double) As Double
            value = Abs(value)
            If Form1.mode = Form1.deg.Text Then
                value = value * PI / 180
            End If
            value = value - (value \ (2 * PI) * 2 * PI) 'optional
            Dim anw = 0.0
            Dim n = 0
            Dim temp = 0.0
            While n < 100
                temp = Exp(value, 2 * n) / Factorial(2 * n)
                If (n Mod 2) = 0 Then
                    anw += temp
                Else
                    anw -= temp
                End If
                n += 1
            End While
            anw = Math.Round(anw, 9)
            Return anw
        End Function

        Public Shared Function Factorial(value As Double) As Double
            If value > 171 Then
                Return Factorial(171) 'dont fix whats not broken
            End If
            If value < 2 Then
                Return 1
            End If
            Return value * Factorial(value - 1)
        End Function
    End Class

    Public Function Operander(x As Object, y As Object, op As String)
        Dim value = Nothing
        Select Case op
            Case Exponent.Text
                value = Jank.Exponent(x, y)
            Case "&"
                value = x & "" & y
            Case Minus.Text
                value = x - y
            Case Plus.Text
                value = x + y
            Case Multiply.Text
                value = x * y
            Case Divide.Text
                value = x / y
            Case Modulus.Text
                value = x Mod y
            Case radical.Text
                value = Jank.Radical(y, x)
        End Select
        Return value
    End Function

    Private Sub ButtonClick(sender As Object, e As EventArgs) Handles Button1.Click, Button2.Click, Button3.Click, Button4.Click, Button5.Click, Button6.Click, Button7.Click, Button8.Click, Button9.Click, Button0.Click
        mdisplay.operateAssign(TextBox1.Text, sender.Text, "&")
    End Sub

    Private Sub DotClick(sender As Object, e As EventArgs) Handles Dot.Click, Negator.Click
        If sender.Text = Dot.Text And Not TextBox1.Text.Contains(".") Then 'superior dot check
            TextBox1.Text &= "."
        ElseIf sender.Text = Negator.Text Then
            mdisplay.operateAssign(0, TextBox1.Text, "-")
        End If
    End Sub

    Public Function YoinkNumber()
        If getLast(mtuple.ops) = RightParen.Text Then
            Return True
        End If

        mtuple.numbers.Add(mdisplay.vget())
        Return False
    End Function

    Private Sub Operator_Click(sender As Object, e As EventArgs) Handles Plus.Click, Minus.Click, Multiply.Click, Modulus.Click, Exponent.Click, Divide.Click
        TextBox2.Text &= If(Not YoinkNumber(), mdisplay.reset(), "") & If(sender.text = RightParen.Text, "", " ") & sender.text() & " " 'grab the next number unless we end with a close paren
        mtuple.ops.Add(sender.Text)
    End Sub

    Private Sub radical_Click(sender As Object, e As EventArgs) Handles radical.Click
        If RightParen.Text.Equals(getLast(mtuple.ops)) Then
            Return
        End If
        mtuple.ops.Add(sender.Text)
        TextBox2.Text &= sender.Text
        mtuple.numbers.Add(mdisplay.vget())
        TextBox2.Text &= " " & mdisplay.reset()
        LeftParen.PerformClick()
    End Sub

    Private Sub sqrt_Click(sender As Object, e As EventArgs) Handles sqrt.Click
        Dim temp = mdisplay.vget()
        mdisplay.vset(2)
        radical.PerformClick()
        mdisplay.vset(temp)
    End Sub

    Private Sub Single_Ladies(sender As Object, e As EventArgs) Handles Fact.Click, Log.Click, Ln.Click, Log2.Click, Tan.Click, Cos.Click, Sin.Click
        If RightParen.Text.Equals(getLast(mtuple.ops)) Then
            Return
        End If
        mtuple.ops.Add(sender.Text)
        TextBox2.Text &= sender.Text
        LeftParen.PerformClick()
    End Sub

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        If TextBox1.Text = "0" Then
            mdisplay.vset(0)
            mtuple.Reset()
            TextBox2.Text = ""
        Else
            TextBox1.Text = "0"
        End If
    End Sub

    Private Sub Equal_Click(sender As Object, e As EventArgs) Handles Equal.Click
        YoinkNumber()
        While mtuple.leftCount > 0
            mtuple.ops.Add(RightParen.Text)
            mtuple.leftCount -= 1
        End While
        ''begin debugin stuff
        Dim temp0 = Function(e0 As ArrayList, anw As String) As String
                        anw = ""
                        For Each x In e0
                            anw &= x
                        Next
                        Return anw
                    End Function
        Dim temp = ""
        Console.WriteLine(temp0(mtuple.ops, temp))
        Console.WriteLine(temp0(mtuple.numbers, temp))
        'end debugin stuff
        Try
            mtuple = compute(mtuple)
            mdisplay.vset(mtuple.Reset())
        Catch ex As Exception
            TextBox1.Text = "error"
            Console.WriteLine(ex.ToString())
        End Try
        TextBox2.Text = ""
    End Sub

    Public Function Pull(e As Object, index As Integer)
        Dim temp = Nothing 'i've tried nothing and i'm all out of ideas
        Try
            temp = e.item(index)
            e.RemoveAt(index)
        Catch ex As Exception 'pulling nothing returns nothing
        End Try
        Return temp
    End Function

    Public Function compute(e As Tuple)
        If e.ops.Count = 0 Then
            Return e
        End If
        If e.ops.Contains(LeftParen.Text) Then
            Dim temp = New Tuple
            Dim closeParen = e.ops.IndexOf(RightParen.Text)
            e.RefilWindex(closeParen) 'setup windex
            e.ops.RemoveAt(closeParen)
            For i = (closeParen - 1) To 0 Step -1
                If e.ops.Item(i) <> LeftParen.Text Then
                    If Tuple.IsDouble(e.ops.Item(i)) Then
                        e.windex -= 1 'assert windex is never negative
                    End If
                    temp.ops.Add(Pull(e.ops, i))
                    temp.numbers.Add(Pull(e.numbers, e.windex)) 'windex kills the bugs
                    temp.numbers.Add(Pull(e.numbers, e.windex))
                Else
                    e.ops.RemoveAt(i)
                    temp = compute(temp)
                    e.RefilWindex(i) 'mabye use refil instead?
                    If temp.numbers.Count > 0 Then
                        e.numbers.Insert(e.windex, temp.numbers.Item(0))
                    End If
                    SinglesWillNotBePaired(e, i) 'process single number operators here beacuse they always precede a paren
                    Exit For
                End If
            Next
            Return compute(e)
        Else
            For i = 0 To order.count() - 1
                Process(e, order.item(i)) ''order is created on load
            Next
            Return compute(e)
        End If
    End Function
    Public Sub SinglesWillNotBePaired(e As Tuple, i As Integer)
        i -= 1
        If i < 0 Or i >= e.ops.Count() Then
            Return
        End If
        If Tuple.IsDouble(e.ops.Item(i)) Or e.ops.Item(i) = LeftParen.Text Then
            Return
        End If
        Dim value As Double
        value = Pull(e.numbers, e.windex)
        Select Case e.ops.Item(i)
            Case Log.Text
                value = Jank.log(value, 10)
            Case Ln.Text
                value = Jank.ln(value)
            Case Log2.Text
                value = Jank.log(value, 2)
            Case Fact.Text 'what about fractions?
                value \= 1
                value = Jank.Factorial(value)
            Case Cos.Text
                value = Jank.Cos(value)
            Case Sin.Text
                value = Jank.Sin(value)
            Case Tan.Text
                value = Jank.Tan(value)
        End Select
        e.ops.RemoveAt(i)
        e.numbers.Insert(e.windex, value)
    End Sub

    Public Sub Process(e As Tuple, search As ArrayList) 'shouldnt have any parens 'todo add mutiple search paramaters to search for at the same time and precesdense
        Dim i = 0
        While i < e.ops.Count()
            If search.Contains(e.ops.Item(i)) Then
                e.RefilWindex(i) 'added cuz radical fudges up operator list
                'pull is called shuffling down the next guy so the second pull grabs the same one
                e.numbers.Insert(i, Operander(Pull(e.numbers, e.windex), Pull(e.numbers, e.windex), e.ops.Item(i)))
                e.ops.RemoveAt(i)
            Else
                i += 1
            End If
        End While
    End Sub

    Private Sub LeftParen_Click(sender As Object, e As EventArgs) Handles LeftParen.Click
        If RightParen.Text.Equals(getLast(mtuple.ops)) Then
            Return
        End If
        mtuple.leftCount += 1
        TextBox2.Text &= sender.Text
        mtuple.ops.Add(sender.Text)
        RightParen.Enabled = True
    End Sub

    Public Function getLast(arr As ArrayList)
        If arr.Count > 0 Then
            Return arr.Item(arr.Count - 1)
        End If
        Return Nothing
    End Function

    Private Sub RightParen_Click(sender As Object, e As EventArgs) Handles RightParen.Click
        mtuple.leftCount -= 1
        Operator_Click(sender, e)
        If mtuple.leftCount = 0 Then
            RightParen.Enabled = False
        End If
    End Sub

    Private Sub pi_Click(sender As Object, e As EventArgs) Handles pi.Click
        mdisplay.vset(Jank.PI)
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If TextBox1.Text.Length > 1 Then
            TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.Length - 1)
        Else
            TextBox1.Text = 0
        End If
    End Sub

    Dim mem As Double
    Private Sub m_Click(sender As Object, e As EventArgs) Handles mc.Click, mplus.Click, mminus.Click 'saves like 12 lines
        Select Case sender.text
            Case mc.Text
                mem = 0.0
                mr.Text = "recall"
                Return
            Case mplus.Text
                mem += mdisplay.vget()
            Case mminus.Text
                mem -= mdisplay.vget()
        End Select
        mr.Text = mem
    End Sub '14

    Private Sub mr_click(sender As Object, e As EventArgs) Handles mr.Click
        mdisplay.vset(mem)
    End Sub

    Dim mode As String 'default mode
    Private Sub mode_Click(sender As Object, e As EventArgs) Handles deg.Click, radian.Click 'mabye use a list of buttons
        mode = sender.text
        deg.Enabled = Not deg.Enabled
        radian.Enabled = Not radian.Enabled
    End Sub

    Private Sub mode_change(sender As Button, e As EventArgs) Handles deg.EnabledChanged, radian.EnabledChanged
        If sender.Enabled Then
            sender.BackColor = SystemColors.ControlDark
        Else
            sender.BackColor = SystemColors.ControlLight
        End If
    End Sub

    Private Sub dec_Click(sender As Object, e As EventArgs) Handles dec.Click
        Try
            boxHex.Text = decToBaseLessThan16(boxDec.Text, 16)
        Catch ex As Exception
            boxHex.Text = "error"
        End Try
    End Sub

    Public Function decToBaseLessThan16(ByVal input As Long, ByVal base As Integer) As String
        Dim anw = ""
        Dim temp = ""
        Dim counter = 0
        While input <> 0
            temp = input And &HF
            Select Case temp
                Case "10"
                    temp = buttA.Text
                Case "11"
                    temp = buttB.Text
                Case "12"
                    temp = buttC.Text
                Case "13"
                    temp = buttD.Text
                Case "14"
                    temp = buttE.Text
                Case "15"
                    temp = buttF.Text
                Case Else
                    temp = CInt(temp).ToString()
            End Select
            anw = temp & anw
            input >>= 4
            counter += 4
            If counter >= 64 Then 'ask me no questions and ill tell you no lies
                Return anw
            End If
        End While
        Return anw
    End Function

    Private Sub hex_Click(sender As Object, e As EventArgs) Handles hex.Click
        Try
            boxDec.Text = hexToDec(boxHex.Text)
        Catch ex As Exception
            boxDec.Text = "error"
        End Try
    End Sub

    Public Function hexToDec(input As String) As String
        Dim val As Long
        Dim temp As Long
        Dim endian = input.Length() - 1
        If input = "" Then
            Return ""
        End If
        For i = endian To 0 Step -1
            Dim switch = input.Chars(i)
            Select Case switch
                Case buttF.Text.Chars(0)
                    temp = CLng(15)
                Case buttE.Text.Chars(0)
                    temp = CLng(14)
                Case buttD.Text.Chars(0)
                    temp = CLng(13)
                Case buttC.Text.Chars(0)
                    temp = CLng(12)
                Case buttB.Text.Chars(0)
                    temp = CLng(11)
                Case buttA.Text.Chars(0)
                    temp = CLng(10)
                Case Else
                    temp = Long.Parse(switch)
            End Select
            val = val Or (temp << ((endian - i) * 4))
        Next
        Return val
    End Function

    Private Sub yoink_Click(sender As Object, e As EventArgs) Handles yoink.Click
        boxDec.Text = mdisplay.vget()
    End Sub

    Private Sub yeet_Click(sender As Object, e As EventArgs) Handles yeet.Click
        Try
            mdisplay.vset(Double.Parse(boxDec.Text))
        Catch ex As Exception
            boxDec.Text = "error"
        End Try
    End Sub

    Private Sub buttHex_Click(sender As Object, e As EventArgs) Handles buttA.Click, buttB.Click, buttC.Click, buttD.Click, buttE.Click, buttF.Click
        boxHex.Text &= sender.Text
    End Sub
End Class
