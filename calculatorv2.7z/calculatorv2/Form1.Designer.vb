﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button0 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Dot = New System.Windows.Forms.Button()
        Me.Equal = New System.Windows.Forms.Button()
        Me.Multiply = New System.Windows.Forms.Button()
        Me.Divide = New System.Windows.Forms.Button()
        Me.Minus = New System.Windows.Forms.Button()
        Me.Clear = New System.Windows.Forms.Button()
        Me.Plus = New System.Windows.Forms.Button()
        Me.Modulus = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.Label()
        Me.Exponent = New System.Windows.Forms.Button()
        Me.LeftParen = New System.Windows.Forms.Button()
        Me.RightParen = New System.Windows.Forms.Button()
        Me.Negator = New System.Windows.Forms.Button()
        Me.Fact = New System.Windows.Forms.Button()
        Me.Sin = New System.Windows.Forms.Button()
        Me.Cos = New System.Windows.Forms.Button()
        Me.Tan = New System.Windows.Forms.Button()
        Me.Log = New System.Windows.Forms.Button()
        Me.Ln = New System.Windows.Forms.Button()
        Me.Log2 = New System.Windows.Forms.Button()
        Me.pi = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.boxDec = New System.Windows.Forms.TextBox()
        Me.dec = New System.Windows.Forms.Button()
        Me.hex = New System.Windows.Forms.Button()
        Me.mr = New System.Windows.Forms.Button()
        Me.mc = New System.Windows.Forms.Button()
        Me.mplus = New System.Windows.Forms.Button()
        Me.mminus = New System.Windows.Forms.Button()
        Me.boxHex = New System.Windows.Forms.TextBox()
        Me.deg = New System.Windows.Forms.Button()
        Me.radian = New System.Windows.Forms.Button()
        Me.yoink = New System.Windows.Forms.Button()
        Me.buttD = New System.Windows.Forms.Button()
        Me.buttE = New System.Windows.Forms.Button()
        Me.buttF = New System.Windows.Forms.Button()
        Me.buttC = New System.Windows.Forms.Button()
        Me.buttB = New System.Windows.Forms.Button()
        Me.buttA = New System.Windows.Forms.Button()
        Me.yeet = New System.Windows.Forms.Button()
        Me.radical = New System.Windows.Forms.Button()
        Me.sqrt = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(3, 135)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 60)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button0
        '
        Me.Button0.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button0.Location = New System.Drawing.Point(3, 201)
        Me.Button0.Name = "Button0"
        Me.Button0.Size = New System.Drawing.Size(76, 60)
        Me.Button0.TabIndex = 9
        Me.Button0.Text = "0"
        Me.Button0.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(167, 3)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(76, 60)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(85, 3)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(76, 60)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(3, 3)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(76, 60)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(167, 69)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(76, 60)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(85, 69)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(76, 60)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(3, 69)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(76, 60)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(167, 135)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(76, 60)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(85, 135)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 60)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Dot
        '
        Me.Dot.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dot.Location = New System.Drawing.Point(85, 201)
        Me.Dot.Name = "Dot"
        Me.Dot.Size = New System.Drawing.Size(76, 60)
        Me.Dot.TabIndex = 10
        Me.Dot.Text = "."
        Me.Dot.UseVisualStyleBackColor = True
        '
        'Equal
        '
        Me.Equal.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Equal.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Equal.Location = New System.Drawing.Point(16, 494)
        Me.Equal.Name = "Equal"
        Me.Equal.Size = New System.Drawing.Size(714, 124)
        Me.Equal.TabIndex = 16
        Me.Equal.Text = "="
        Me.Equal.UseVisualStyleBackColor = True
        '
        'Multiply
        '
        Me.Multiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Multiply.Location = New System.Drawing.Point(85, 69)
        Me.Multiply.Name = "Multiply"
        Me.Multiply.Size = New System.Drawing.Size(76, 60)
        Me.Multiply.TabIndex = 12
        Me.Multiply.Text = "*"
        Me.Multiply.UseVisualStyleBackColor = True
        '
        'Divide
        '
        Me.Divide.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Divide.Location = New System.Drawing.Point(3, 135)
        Me.Divide.Name = "Divide"
        Me.Divide.Size = New System.Drawing.Size(76, 60)
        Me.Divide.TabIndex = 13
        Me.Divide.Text = "/"
        Me.Divide.UseVisualStyleBackColor = True
        '
        'Minus
        '
        Me.Minus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Minus.Location = New System.Drawing.Point(85, 201)
        Me.Minus.Name = "Minus"
        Me.Minus.Size = New System.Drawing.Size(76, 60)
        Me.Minus.TabIndex = 14
        Me.Minus.Text = "-"
        Me.Minus.UseVisualStyleBackColor = True
        '
        'Clear
        '
        Me.Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear.Location = New System.Drawing.Point(3, 3)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(159, 60)
        Me.Clear.TabIndex = 18
        Me.Clear.Text = "Clear Screen"
        Me.Clear.UseVisualStyleBackColor = True
        '
        'Plus
        '
        Me.Plus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Plus.Location = New System.Drawing.Point(3, 201)
        Me.Plus.Name = "Plus"
        Me.Plus.Size = New System.Drawing.Size(76, 60)
        Me.Plus.TabIndex = 15
        Me.Plus.Text = "+"
        Me.Plus.UseVisualStyleBackColor = True
        '
        'Modulus
        '
        Me.Modulus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modulus.Location = New System.Drawing.Point(85, 135)
        Me.Modulus.Name = "Modulus"
        Me.Modulus.Size = New System.Drawing.Size(76, 60)
        Me.Modulus.TabIndex = 21
        Me.Modulus.Text = "%"
        Me.Modulus.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Dock = System.Windows.Forms.DockStyle.Top
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(0, 0)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(1194, 31)
        Me.TextBox2.TabIndex = 24
        Me.TextBox2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(0, 31)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(1194, 31)
        Me.TextBox1.TabIndex = 25
        Me.TextBox1.Text = "0"
        Me.TextBox1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Exponent
        '
        Me.Exponent.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exponent.Location = New System.Drawing.Point(3, 69)
        Me.Exponent.Name = "Exponent"
        Me.Exponent.Size = New System.Drawing.Size(76, 60)
        Me.Exponent.TabIndex = 26
        Me.Exponent.Text = "^"
        Me.Exponent.UseVisualStyleBackColor = True
        '
        'LeftParen
        '
        Me.LeftParen.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LeftParen.Location = New System.Drawing.Point(3, 3)
        Me.LeftParen.Name = "LeftParen"
        Me.LeftParen.Size = New System.Drawing.Size(76, 60)
        Me.LeftParen.TabIndex = 28
        Me.LeftParen.Text = "("
        Me.LeftParen.UseVisualStyleBackColor = True
        '
        'RightParen
        '
        Me.RightParen.Enabled = False
        Me.RightParen.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RightParen.Location = New System.Drawing.Point(85, 3)
        Me.RightParen.Name = "RightParen"
        Me.RightParen.Size = New System.Drawing.Size(76, 60)
        Me.RightParen.TabIndex = 29
        Me.RightParen.Text = ")"
        Me.RightParen.UseVisualStyleBackColor = True
        '
        'Negator
        '
        Me.Negator.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Negator.Location = New System.Drawing.Point(167, 201)
        Me.Negator.Name = "Negator"
        Me.Negator.Size = New System.Drawing.Size(76, 60)
        Me.Negator.TabIndex = 30
        Me.Negator.Text = "+/-"
        Me.Negator.UseVisualStyleBackColor = True
        '
        'Fact
        '
        Me.Fact.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Fact.Location = New System.Drawing.Point(3, 135)
        Me.Fact.Name = "Fact"
        Me.Fact.Size = New System.Drawing.Size(159, 60)
        Me.Fact.TabIndex = 31
        Me.Fact.Text = "Factorial"
        Me.Fact.UseVisualStyleBackColor = True
        '
        'Sin
        '
        Me.Sin.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sin.Location = New System.Drawing.Point(10, 335)
        Me.Sin.Name = "Sin"
        Me.Sin.Size = New System.Drawing.Size(76, 60)
        Me.Sin.TabIndex = 32
        Me.Sin.Text = "Sin"
        Me.Sin.UseVisualStyleBackColor = True
        '
        'Cos
        '
        Me.Cos.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cos.Location = New System.Drawing.Point(92, 335)
        Me.Cos.Name = "Cos"
        Me.Cos.Size = New System.Drawing.Size(76, 60)
        Me.Cos.TabIndex = 33
        Me.Cos.Text = "Cos"
        Me.Cos.UseVisualStyleBackColor = True
        '
        'Tan
        '
        Me.Tan.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tan.Location = New System.Drawing.Point(175, 335)
        Me.Tan.Name = "Tan"
        Me.Tan.Size = New System.Drawing.Size(76, 60)
        Me.Tan.TabIndex = 34
        Me.Tan.Text = "Tan"
        Me.Tan.UseVisualStyleBackColor = True
        '
        'Log
        '
        Me.Log.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Log.Location = New System.Drawing.Point(10, 401)
        Me.Log.Name = "Log"
        Me.Log.Size = New System.Drawing.Size(76, 60)
        Me.Log.TabIndex = 35
        Me.Log.Text = "Log"
        Me.Log.UseVisualStyleBackColor = True
        '
        'Ln
        '
        Me.Ln.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Ln.Location = New System.Drawing.Point(92, 401)
        Me.Ln.Name = "Ln"
        Me.Ln.Size = New System.Drawing.Size(76, 60)
        Me.Ln.TabIndex = 36
        Me.Ln.Text = "Ln"
        Me.Ln.UseVisualStyleBackColor = True
        '
        'Log2
        '
        Me.Log2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Log2.Location = New System.Drawing.Point(175, 401)
        Me.Log2.Name = "Log2"
        Me.Log2.Size = New System.Drawing.Size(76, 60)
        Me.Log2.TabIndex = 37
        Me.Log2.Text = "Button10"
        Me.Log2.UseVisualStyleBackColor = True
        '
        'pi
        '
        Me.pi.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pi.Location = New System.Drawing.Point(257, 401)
        Me.pi.Name = "pi"
        Me.pi.Size = New System.Drawing.Size(76, 60)
        Me.pi.TabIndex = 40
        Me.pi.Text = "pi"
        Me.pi.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(3, 69)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(159, 60)
        Me.Button10.TabIndex = 41
        Me.Button10.Text = "Backspace"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'boxDec
        '
        Me.boxDec.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.boxDec.Location = New System.Drawing.Point(109, 33)
        Me.boxDec.Margin = New System.Windows.Forms.Padding(2)
        Me.boxDec.Name = "boxDec"
        Me.boxDec.Size = New System.Drawing.Size(291, 32)
        Me.boxDec.TabIndex = 42
        '
        'dec
        '
        Me.dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dec.Location = New System.Drawing.Point(6, 19)
        Me.dec.Name = "dec"
        Me.dec.Size = New System.Drawing.Size(98, 60)
        Me.dec.TabIndex = 43
        Me.dec.Text = "dec"
        Me.dec.UseVisualStyleBackColor = True
        '
        'hex
        '
        Me.hex.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hex.Location = New System.Drawing.Point(6, 19)
        Me.hex.Name = "hex"
        Me.hex.Size = New System.Drawing.Size(98, 60)
        Me.hex.TabIndex = 44
        Me.hex.Text = "hex"
        Me.hex.UseVisualStyleBackColor = True
        '
        'mr
        '
        Me.mr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mr.Location = New System.Drawing.Point(3, 201)
        Me.mr.Name = "mr"
        Me.mr.Size = New System.Drawing.Size(76, 60)
        Me.mr.TabIndex = 46
        Me.mr.Text = "recall"
        Me.mr.UseVisualStyleBackColor = True
        '
        'mc
        '
        Me.mc.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mc.Location = New System.Drawing.Point(85, 201)
        Me.mc.Name = "mc"
        Me.mc.Size = New System.Drawing.Size(76, 60)
        Me.mc.TabIndex = 47
        Me.mc.Text = "mc"
        Me.mc.UseVisualStyleBackColor = True
        '
        'mplus
        '
        Me.mplus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mplus.Location = New System.Drawing.Point(3, 267)
        Me.mplus.Name = "mplus"
        Me.mplus.Size = New System.Drawing.Size(76, 60)
        Me.mplus.TabIndex = 48
        Me.mplus.Text = "m+"
        Me.mplus.UseVisualStyleBackColor = True
        '
        'mminus
        '
        Me.mminus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mminus.Location = New System.Drawing.Point(85, 267)
        Me.mminus.Name = "mminus"
        Me.mminus.Size = New System.Drawing.Size(76, 60)
        Me.mminus.TabIndex = 49
        Me.mminus.Text = "m-"
        Me.mminus.UseVisualStyleBackColor = True
        '
        'boxHex
        '
        Me.boxHex.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.boxHex.Location = New System.Drawing.Point(110, 34)
        Me.boxHex.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.boxHex.Name = "boxHex"
        Me.boxHex.Size = New System.Drawing.Size(291, 32)
        Me.boxHex.TabIndex = 50
        '
        'deg
        '
        Me.deg.Enabled = False
        Me.deg.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deg.Location = New System.Drawing.Point(257, 335)
        Me.deg.Name = "deg"
        Me.deg.Size = New System.Drawing.Size(76, 60)
        Me.deg.TabIndex = 54
        Me.deg.Text = "deg"
        Me.deg.UseVisualStyleBackColor = True
        '
        'radian
        '
        Me.radian.Enabled = False
        Me.radian.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radian.Location = New System.Drawing.Point(340, 335)
        Me.radian.Name = "radian"
        Me.radian.Size = New System.Drawing.Size(76, 60)
        Me.radian.TabIndex = 55
        Me.radian.Text = "rad"
        Me.radian.UseVisualStyleBackColor = True
        '
        'yoink
        '
        Me.yoink.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.yoink.Location = New System.Drawing.Point(587, 68)
        Me.yoink.Name = "yoink"
        Me.yoink.Size = New System.Drawing.Size(242, 60)
        Me.yoink.TabIndex = 56
        Me.yoink.Text = "set dec from current"
        Me.yoink.UseVisualStyleBackColor = True
        '
        'buttD
        '
        Me.buttD.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttD.Location = New System.Drawing.Point(3, 69)
        Me.buttD.Name = "buttD"
        Me.buttD.Size = New System.Drawing.Size(76, 60)
        Me.buttD.TabIndex = 57
        Me.buttD.Text = "d"
        Me.buttD.UseVisualStyleBackColor = True
        '
        'buttE
        '
        Me.buttE.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttE.Location = New System.Drawing.Point(85, 69)
        Me.buttE.Name = "buttE"
        Me.buttE.Size = New System.Drawing.Size(76, 60)
        Me.buttE.TabIndex = 58
        Me.buttE.Text = "e"
        Me.buttE.UseVisualStyleBackColor = True
        '
        'buttF
        '
        Me.buttF.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttF.Location = New System.Drawing.Point(167, 69)
        Me.buttF.Name = "buttF"
        Me.buttF.Size = New System.Drawing.Size(76, 60)
        Me.buttF.TabIndex = 59
        Me.buttF.Text = "f"
        Me.buttF.UseVisualStyleBackColor = True
        '
        'buttC
        '
        Me.buttC.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttC.Location = New System.Drawing.Point(167, 3)
        Me.buttC.Name = "buttC"
        Me.buttC.Size = New System.Drawing.Size(76, 60)
        Me.buttC.TabIndex = 60
        Me.buttC.Text = "c"
        Me.buttC.UseVisualStyleBackColor = True
        '
        'buttB
        '
        Me.buttB.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttB.Location = New System.Drawing.Point(85, 3)
        Me.buttB.Name = "buttB"
        Me.buttB.Size = New System.Drawing.Size(76, 60)
        Me.buttB.TabIndex = 61
        Me.buttB.Text = "b"
        Me.buttB.UseVisualStyleBackColor = True
        '
        'buttA
        '
        Me.buttA.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttA.Location = New System.Drawing.Point(3, 3)
        Me.buttA.Name = "buttA"
        Me.buttA.Size = New System.Drawing.Size(76, 60)
        Me.buttA.TabIndex = 62
        Me.buttA.Text = "a"
        Me.buttA.UseVisualStyleBackColor = True
        '
        'yeet
        '
        Me.yeet.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.yeet.Location = New System.Drawing.Point(835, 68)
        Me.yeet.Name = "yeet"
        Me.yeet.Size = New System.Drawing.Size(146, 60)
        Me.yeet.TabIndex = 63
        Me.yeet.Text = "dec to current"
        Me.yeet.UseVisualStyleBackColor = True
        '
        'radical
        '
        Me.radical.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radical.Location = New System.Drawing.Point(340, 401)
        Me.radical.Name = "radical"
        Me.radical.Size = New System.Drawing.Size(76, 60)
        Me.radical.TabIndex = 64
        Me.radical.Text = "√"
        Me.radical.UseVisualStyleBackColor = True
        '
        'sqrt
        '
        Me.sqrt.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sqrt.Location = New System.Drawing.Point(422, 401)
        Me.sqrt.Name = "sqrt"
        Me.sqrt.Size = New System.Drawing.Size(76, 60)
        Me.sqrt.TabIndex = 65
        Me.sqrt.Text = "√2"
        Me.sqrt.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Button7)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button8)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button9)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button6)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button0)
        Me.FlowLayoutPanel1.Controls.Add(Me.Dot)
        Me.FlowLayoutPanel1.Controls.Add(Me.Negator)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(12, 68)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(249, 266)
        Me.FlowLayoutPanel1.TabIndex = 66
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Controls.Add(Me.Clear)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button10)
        Me.FlowLayoutPanel2.Controls.Add(Me.Fact)
        Me.FlowLayoutPanel2.Controls.Add(Me.mr)
        Me.FlowLayoutPanel2.Controls.Add(Me.mc)
        Me.FlowLayoutPanel2.Controls.Add(Me.mplus)
        Me.FlowLayoutPanel2.Controls.Add(Me.mminus)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(422, 71)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(169, 329)
        Me.FlowLayoutPanel2.TabIndex = 67
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Controls.Add(Me.buttA)
        Me.FlowLayoutPanel3.Controls.Add(Me.buttB)
        Me.FlowLayoutPanel3.Controls.Add(Me.buttC)
        Me.FlowLayoutPanel3.Controls.Add(Me.buttD)
        Me.FlowLayoutPanel3.Controls.Add(Me.buttE)
        Me.FlowLayoutPanel3.Controls.Add(Me.buttF)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(590, 310)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(247, 136)
        Me.FlowLayoutPanel3.TabIndex = 68
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dec)
        Me.GroupBox1.Controls.Add(Me.boxDec)
        Me.GroupBox1.Location = New System.Drawing.Point(590, 137)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(409, 82)
        Me.GroupBox1.TabIndex = 69
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.hex)
        Me.GroupBox3.Controls.Add(Me.boxHex)
        Me.GroupBox3.Location = New System.Drawing.Point(590, 222)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(409, 82)
        Me.GroupBox3.TabIndex = 70
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GroupBox3"
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Controls.Add(Me.LeftParen)
        Me.FlowLayoutPanel4.Controls.Add(Me.RightParen)
        Me.FlowLayoutPanel4.Controls.Add(Me.Exponent)
        Me.FlowLayoutPanel4.Controls.Add(Me.Multiply)
        Me.FlowLayoutPanel4.Controls.Add(Me.Divide)
        Me.FlowLayoutPanel4.Controls.Add(Me.Modulus)
        Me.FlowLayoutPanel4.Controls.Add(Me.Plus)
        Me.FlowLayoutPanel4.Controls.Add(Me.Minus)
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(865, 326)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(170, 265)
        Me.FlowLayoutPanel4.TabIndex = 71
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1194, 846)
        Me.Controls.Add(Me.FlowLayoutPanel4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.FlowLayoutPanel3)
        Me.Controls.Add(Me.FlowLayoutPanel2)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.sqrt)
        Me.Controls.Add(Me.radical)
        Me.Controls.Add(Me.yeet)
        Me.Controls.Add(Me.yoink)
        Me.Controls.Add(Me.radian)
        Me.Controls.Add(Me.deg)
        Me.Controls.Add(Me.pi)
        Me.Controls.Add(Me.Log2)
        Me.Controls.Add(Me.Ln)
        Me.Controls.Add(Me.Log)
        Me.Controls.Add(Me.Tan)
        Me.Controls.Add(Me.Cos)
        Me.Controls.Add(Me.Sin)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Equal)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Button0 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Dot As Button
    Friend WithEvents Equal As Button
    Friend WithEvents Multiply As Button
    Friend WithEvents Divide As Button
    Friend WithEvents Minus As Button
    Friend WithEvents Clear As Button
    Friend WithEvents Plus As Button
    Friend WithEvents Modulus As System.Windows.Forms.Button
    Public WithEvents TextBox2 As Label
    Public WithEvents TextBox1 As Label
    Friend WithEvents Exponent As Button
    Friend WithEvents LeftParen As System.Windows.Forms.Button
    Friend WithEvents RightParen As System.Windows.Forms.Button
    Friend WithEvents Negator As System.Windows.Forms.Button
    Friend WithEvents Fact As Button
    Friend WithEvents Sin As Button
    Friend WithEvents Cos As Button
    Friend WithEvents Tan As Button
    Friend WithEvents Log As Button
    Friend WithEvents Ln As Button
    Friend WithEvents Log2 As Button
    Friend WithEvents pi As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents boxDec As TextBox
    Friend WithEvents dec As Button
    Friend WithEvents hex As Button
    Friend WithEvents mr As Button
    Friend WithEvents mc As Button
    Friend WithEvents mplus As Button
    Friend WithEvents mminus As Button
    Friend WithEvents boxHex As TextBox
    Friend WithEvents deg As Button
    Friend WithEvents radian As Button
    Friend WithEvents yoink As Button
    Friend WithEvents buttD As Button
    Friend WithEvents buttE As Button
    Friend WithEvents buttF As Button
    Friend WithEvents buttC As Button
    Friend WithEvents buttB As Button
    Friend WithEvents buttA As Button
    Friend WithEvents yeet As Button
    Friend WithEvents radical As Button
    Friend WithEvents sqrt As Button
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel3 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents FlowLayoutPanel4 As System.Windows.Forms.FlowLayoutPanel
End Class
